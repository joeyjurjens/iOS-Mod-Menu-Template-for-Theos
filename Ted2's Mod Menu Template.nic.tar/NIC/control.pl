NIC->prompt("BINARYNAME", "Enter binary name of the app (if you know it)", {default => ""});

NIC->prompt("APPNAME", "Enter name of the app", {default => ""});

NIC->prompt("APPVERSION", "Enter current version of the app", {default => "1.0"});

NIC->prompt("SITE", "Enter the site where the hack is for", {default => ""});